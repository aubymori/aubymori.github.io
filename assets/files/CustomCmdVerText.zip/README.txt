Custom CMD version text, without breaking scripts!
by aubymori, 2024/07/13

How To Install
===========================================================

1. Open "System32\en-US\cmd.exe.mui" in RisohEditor,
and change the Message Table string with ID 0x2397 to what
you want. The version is 5.2.3790 by default.

2. Copy the files into %WINDIR% (after taking ownership
and renaming the original files, of course.)

3. Open CMD. You should have the custom version text at the
top, and typing `ver` should result in the real OS version.


Making your own MUI file (for locales that aren't en-US)
===========================================================

1. Copy "%WINDIR%\System32\[your locale]\cmd.exe.mui" to a
safe location for editing.

2. Open it in RisohEditor, and add your custom version
string to the message table with the ID 0x2397.

4. Save it, rename the original file in System32, and put
yours in.