Instructions to install:
Place shell32legacy.dll into C:\Windows\System32 
(do NOT replace your actuall shell32.dll with this, unless you want a bricked install!!)

Ensure you have StartIsBack++ 2.9.19 installed, 
then replace StartIsBackCfg.exe and StartIsBack64.dll with the copies provided, and restart explorer.
(You may need to rename the original StartIsBack64.dll if that's still in use, 
then place in the new copy, and delete the old one once explorer's restarted)

Then just import CLSID.reg as TrustedInstaller and hope for the best.

NOTE: StartIsBack64.dll also contains other modifications to make it more accurate to 7 
(reduced All Programs padding, no fade, native scrollbars)
If you don't like any of those changes, avoid this modification as-is.