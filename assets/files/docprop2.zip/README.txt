Windows XP "Summary" Tab
by aubymori, 2025/07/17

How To Install
====================================================

1. Copy "System32\docprop2.dll" to C:\Windows\System32,
and "SysWOW64\docprop2.dll" to C:\Windows\SysWOW64.

2. Import the "Import as TI.reg" as TrustedInstaller,
through a tool like RunTI:
https://github.com/aubymori/RunTI

3. Install the Windhawk mod that is in the
"summary-tab-fix.wh.cpp" file.