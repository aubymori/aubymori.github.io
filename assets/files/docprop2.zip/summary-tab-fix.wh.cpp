// ==WindhawkMod==
// @id              summary-tab-fix
// @name            Summary Tab Fix
// @description     Allows XP's Summary tab to load on Win10
// @version         1.0.0
// @author          aubymori
// @github          https://github.com/aubymori
// @include         *
// @compilerOptions -lole32
// ==/WindhawkMod==

// ==WindhawkModReadme==
/*
# Summary Tab Fix
This allows Windows XP's file properties dialog "Summary" tab to work on Windows 10.
This will replace the "Details" tab.
*/
// ==/WindhawkModReadme==

#include <windhawk_utils.h>
#include <initguid.h>

#ifdef _WIN64
#  define STDCALL_STR L"__cdecl"
#else
#  define STDCALL_STR L"__stdcall"
#endif

DEFINE_GUID(CLSID_DocPropShellExtension, 0x883373C3, 0xBF89, 0x11D1, 0xBE,0x35, 0x08,0x00,0x36,0xB1,0x1A,0x03);

HRESULT (__fastcall *_SHCoCreateInstance_orig)(REFCLSID, IUnknown *, DWORD, BOOL, int, REFIID, LPVOID *);
HRESULT __fastcall _SHCoCreateInstance_hook(
    REFCLSID  rclsid,
    IUnknown *pUnkOuter,
    DWORD     dwCoCreateFlags,
    BOOL      bMustBeApproved,
    int       extCoCreateFlags,
    REFIID    riid,
    LPVOID    *ppv
)
{
    if (IsEqualCLSID(rclsid, CLSID_DocPropShellExtension))
    {
        return CoCreateInstance(rclsid, pUnkOuter, dwCoCreateFlags, riid, ppv);
    }
    return _SHCoCreateInstance_orig(rclsid, pUnkOuter, dwCoCreateFlags, bMustBeApproved, extCoCreateFlags, riid, ppv);
}

const WindhawkUtils::SYMBOL_HOOK shell32DllHooks[] = {
    {
        {
            L"long "
            STDCALL_STR
            L" _SHCoCreateInstance(struct _GUID const &,struct IUnknown *,unsigned long,int,enum EXTCOCREATEFLAGS,struct _GUID const &,void * *)"
        },
        &_SHCoCreateInstance_orig,
        _SHCoCreateInstance_hook,
        false
    }  
};

BOOL Wh_ModInit(void)
{
    HMODULE hShell32 = LoadLibraryExW(L"shell32.dll", NULL, LOAD_LIBRARY_SEARCH_SYSTEM32);
    if (!hShell32)
    {
        Wh_Log(L"Failed to load shell32.dll");
        return FALSE;
    }

    if (!WindhawkUtils::HookSymbols(
        hShell32,
        shell32DllHooks,
        ARRAYSIZE(shell32DllHooks)
    ))
    {
        Wh_Log(L"Failed to hook _SHCoCreateInstance");
        return FALSE;
    }

    return TRUE;
}